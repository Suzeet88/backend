const { check, validationResult } = require("express-validator");

exports.addcategoryRules = [
  check("category_name")
    .notEmpty()
    .withMessage("Category name is required")
    .isLength({ min: 3 })
    .withMessage("Category name should be atleast 3 characters long"),
];

exports.updateCategoryRules = [
  check("category_name")
    .optional()
    .isLength({ min: 3 })
    .withMessage("Category name should be atleast 3 characters long"),
];

exports.validationMethod = (req, res, next) => {
  let error = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: error.array() });
  }
  next();
};

// user validation

exports.userRegisterRules = [
  check("username")
    .notEmpty()
    .withMessage("Username is required")
    .isLength({ min: 3 })
    .withMessage("Username must be at least 3 characters")
    .not()
    .isIn(["USER", "admin", "ADMIN", "GOD", "DOG"])
    .withMessage("Invalid username"),
  check("email")
    .notEmpty()
    .withMessage("Email is required")
    .isEmail()
    .withMessage("Email format invalid"),
  check("password")
    .notEmpty()
    .withMessage("Password is required")
    .matches(/[a-z]/)
    .withMessage("Password must consist of at least 1 lowercase alphabet")
    .matches(/[A-Z]/)
    .withMessage("Password must consist of at least 1 uppercase alphabet")
    .matches(/[0-9]/)
    .withMessage("Password must consist of at least 1 number")
    .matches(/[!@#$%_]/)
    .withMessage("Password must consist of at least special character")
    .isLength({ min: 8 })
    .withMessage("Password must be at least 8 characters")
    .isLength({ max: 30 })
    .withMessage("Password must be not exceed 30 characters"),
];
