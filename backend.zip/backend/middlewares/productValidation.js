const { check, validationResult } = require("express-validator");

// Validation rules for adding a product
exports.addProductRules = [
  check("product_name")
    .notEmpty()
    .withMessage("Product name is required")
    .isLength({ min: 3 })
    .withMessage("Product name should be at least 3 characters long"),
  check("price")
    .notEmpty()
    .withMessage("Price is required")
    .isFloat({ gt: 0 })
    .withMessage("Price must be a positive number"),
  check("description")
    .optional()
    .isLength({ max: 500 })
    .withMessage("Description can be up to 500 characters long"),
  check("category")
    .notEmpty()
    .withMessage("Category is required"),
];

// Validation rules for updating a product
exports.updateProductRules = [
  check("product_name")
    .optional()
    .isLength({ min: 3 })
    .withMessage("Product name should be at least 3 characters long"),
  check("price")
    .optional()
    .isFloat({ gt: 0 })
    .withMessage("Price must be a positive number"),
  check("description")
    .optional()
    .isLength({ max: 500 })
    .withMessage("Description can be up to 500 characters long"),
  check("category")
    .optional()
    .notEmpty()
    .withMessage("Category is required"),
];

// Middleware to handle validation errors
exports.validationMethod = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
};
