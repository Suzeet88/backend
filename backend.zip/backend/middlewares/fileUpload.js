const multer = require("multer");
const fs = require("fs"); // file system module
const path = require("path"); // path module

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const fileDestination = "public/uploads";

    if (!fs.existsSync(fileDestination)) {
      fs.mkdirSync(fileDestination, { recursive: true });
    }
    cb(null, fileDestination);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);

    // abc.jpg
    // extname = .jpg
    const extname = path.extname(file.originalname);
    const basename = path.basename(file.originalname, extname);

    const FileName = `${file.fieldname}-${basename}-${uniqueSuffix}${extname}`;

    cb(null, FileName);
  },
});

const fileFilter = (req, file, cb) => {
  if (!file.originalname.match(/[.](jpg|jpeg|png|gif|svg)$/)) {
    return cb(new Error("FILE TYPE INVALID"), false);
  }
  cb(null, true);
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 2000000, // 2MB
  },
  fileFilter: fileFilter,
});

module.exports = upload;
