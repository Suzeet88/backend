// Description: This file contains the middleware functions for authenticating the user.
const jwt = require('jsonwebtoken');

exports.validateLogin = (req , res  , next) => {
    // console.log(req.headers)
     if(!req.headers.authorization) {
         return res.status(401).json({error :"you need to login first"});
     }
     next();
}

exports.requireAdmin = (req , res , next) => {
     let user = jwt.verify(req.headers.authorization , process.env.JWT_SECRET);
     if(user.role == 1) {
         next();
         
     }
     
     else {
          return res.status(401).json({error : "Authorization failed"});
     }
}

