const productModel = require("../models/productModel");

// add product

exports.addProduct = async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: "Please upload a file" });
  }
  let productToAdd = await productModel.create({
    product_name: req.body.product_name,
    product_price: req.body.product_price,
    product_description: req.body.product_description,
    count_in_stock: req.body.count_in_stock,
    category: req.body.category,
    product_image: req.file?.path,
  });
  if (!productToAdd) {
    return res.status(400).json({ message: "product is not added" });
  }
  res.send(productToAdd);
};

// get all products
exports.getAllProducts = async (req, res) => {
  let products = await productModel.find().populate("category");
  if (!products) {
    return res.status(400).json({ message: "No products found" });
  }
  res.send(products);
};

exports.getProductById = async (req, res) => {
  let product = await productModel
    .findById(req.params.id)
    .populate("category", "category_name");
  if (!product) {
    return res.status(400).json({ message: "No product found" });
  }
  res.send(product);
};

// exports.updateProduct = async (req, res) => {
//    let product = await productModel.findById(req.params.id);
//    if(req.file){
//       fs.unlink(product.product_image);
//      product = await productModel.findByIdAndUpdate(req.params.id, {
//        product_name: req.body.product_name,
//        product_price: req.body.product_price,
//        product_description: req.body.product_description,
//        count_in_stock: req.body.count_in_stock,
//        category: req.body.category,
//        product_image: req.file?.path,
//      });

// }
   

 
// //   let product = await productModel.findByIdAndUpdate(req.params.id, {
// //     product_name: req.body.product_name,
// //     product_price: req.body.product_price,
// //     product_description: req.body.product_description,
// //     count_in_stock: req.body.count_in_stock,
// //     category: req.body.category,
// //   });
//   if (!product) {
//     return res.status(400).json({ message: "No product found" });
//   }
//   res.send(product);
// };


exports.updateProduct = async (req, res) => {

  let product = await ProductModel.findById(req.params.id)
    if (req.file) {
        // remove previous file
        fs.unlink(product.product_image);
        // update product_image
        product.product_image = req.file.path
    }
    // update fields
    product.product_name = req.body.product_name ? req.body.product_name : product.product_name
    product_price = req.body.product_price ? req.body.product_price : product.product_price
    product_description = req.body.product_description ? req.body.product_description : product.product_description
    product.count_in_stock = req.body.count_in_stock ? req.body.count_in_stock : product.count_in_stock
    product.category = req.body.category ? req.body.category : product.category
    product.rating = req.body.rating ? req.body.rating : product.rating

    // save updated product
    productToUpdate = await productToUpdate.save()

    if (!productToUpdate) {
        return res.status(400).json({ error: "Something went wrong" })
    }
    res.send(productToUpdate)
  }

exports.deleteProduct = async (req, res) => {
  let product = await productModel.findByIdAndDelete(req.params.id);
  if (!product) {
    return res.status(400).json({ message: "No product found" });
  }
  res.send(product);
};
