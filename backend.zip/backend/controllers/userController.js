const userModel = require('../models/userModel');
const tokenModel = require('../models/tokenModel');
const emailSender = require('../middlewares/emailSender');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const { text } = require('stream/consumers');

const jwt = require('jsonwebtoken');

const saltRounds = 10;

// register user

exports.registerUser = async (req , res) => {
 // destructuring object to get values

 let {username , email , password}  = req.body;

 // check if user already exists
 let userExists =  await userModel.findOne({username});

 if(userExists) {
     return res.staus(400).json({message : "username not available"});
 }


 // check if email already exists

 let emailExists = await userModel.findOne({email});

 if(emailExists) {
    return res.status(400).json({message : "Email already exists"});
    }

 // encrypt password
 const salt = await bcrypt.genSalt(saltRounds);
 const hashedPassword = await bcrypt.hash(password, salt);

 //create user
   let user =  await userModel.create({
          username , 
          email , 
          password : hashedPassword
   })

   if(!user) {
        return res.status(400).json({message : "User not created"});
   }

 // generate verification token

   let token = await tokenModel.create({
       token : crypto.randomBytes(16).toString('hex'),
       user : user._id
   });

   if(!token) {
       return res.status(400).json({message : "Token not generated"});
    }


 // send verification token/link to email
  const URL  = `http://localhost:5000/api/verifyEmail/${token.token}`;

  emailSender({
      from : 'noreply@something.com',
      to : email,
      subject : "verify your account",
        text : `Click on the link to verify your account`,
        html : ` <a href="${URL}"><button>Verify Now</button></a>`
  });

 // send message to user
 res.send(user);
   
}



// verify email

exports.verifyEmail = async (req , res) => {
    // check if token is valid or not
     let token = await tokenModel.findOne({token :  req.params.token});
     if(!token) {
         return res.status(400).json({message : 'invalid token or token expired'});
     }  

    // find user

     let user = await userModel.findById(token.user);
     if(!user) {
         return res.status(400).json({message : 'User not found'});
     }  

    // check if user is already verified

       if(user.isVerified){
              return res.status(400).json({message : 'User already verified'});
       }




    // verify user
        user.isVerified  = true;
        
        // save user
        user = await user.save();
        if(!user) {
            return res.status(400).json({message : 'User not verified'});
        }
        
    // send message to user

    res.send({message : 'user verified sucessfully'});
}


exports.getAllUsers = async (req , res) => {
     let users  = await userModel.find();
      if(!users) {
          return res.status(400).json({error : 'no users found'}  );
      }
      res.send(users);
}   

exports.getUserDetails  = async (req , res) => {
       let users = await userModel.findById(req.params.id);
       if(!users) {
           return res.status(400).json({error : 'user not found'});
       }
}

exports.updateUser = async (req , res) => {
      let users = await userModel.findByIdAndUpdate(req.params.id , {
            username : req.body.username,
            email : req.body.email,
            password : req.body.password
        }); 
        if(!users) {
            return res.status(400).json({error : 'user not updated'});
        }
      
}

exports.deleteUser  = async (req , res) => {
      let users = await userModel.findByIdAndDelete(req.params.id);
      if(!users){
           return res.status(400).json({error : 'user not deleted'});
      }
}

// forgot password 

  exports.forgetPassword  = async(req, res) => {
         // check email if registered or not
        let user = await userModel.findOne({email : req.body.email});
        if(!user){
            return res.status(400).json({error : 'user not found'});
       }
        
         // generate token

         let token = await tokenModel.create({
             token : crypto.randomBytes(16).toString('hex'),
             user: user._id
         })
         if(!token){
            return res.status(400).json({error : 'something went wrong'});
       }

         // send password reset link in email

         const URL = `http://localhost:5000/api/resetPassword/${token.token}`;
    
        emailSender({
           from :'noreply@something.com',
              to : req.body.email,
                subject :"password reset email",
                text    :`Click on the following link to reset your password , ${URL}`,
                html    :` <a href="${URL}"><button>Reset password</button></a>`
        });

         // send message to user
         res.send({message : 'password reset link has been sent to your email'});

  } 

  // reset password

  exports.resetPassword = async (req , res) => {

    // check token if valid or not
    let token = await tokenModel.findOne({token :  req.params.token});
    if(!token) {
        return res.status(400).json({message : 'invalid token or token expired'});
    }  

    // find user 

    let user = await userModel.findById(token.user);
    if(!user) {
        return res.status(400).json({message : 'User not found'});
    }

    // encrypt password 
    let salt = await bcrypt.genSalt(saltRounds);
    let hashedPassword = await bcrypt.hash(req.body.password , salt);



    //update password and save user 
    user.password = hashedPassword;
    user = await user.save();
    if(!user) {
        return res.status(400).json({message : 'password not updated'});
    }

    // send message to user
    res.send({message : 'password updated   sucessfully'});
     
  }


  // login 

   exports.signin = async (req , res) => {
      // get email and password from user

        let {email , password} = req.body;

        // check if email is registered or not

        let user = await userModel.findOne({email});
        if(!user) {
            return res.status(400).json({message : 'email not found'});
        }

        // check if password matches or  not
        let passwordMatch = await bcrypt.compare(password , user.password); 
        if(!passwordMatch) {
            return res.status(400).json({message : 'password not matched'});
        }

        // check if user is verified or not
        if(!user.isVerified){
            return res.status(400).json({message : 'user not verified'});
        }

        // generate  login token 

        let token = jwt.sign({
             id : user._id,
             email : user.email,
             username : user.username,
             role : user.role
        } , process.env.JWT_SECRET);

        // send token to frontend
        
        // Set token in cookie
        res.cookie('myCookie' , token);
        
        res.send({token , user: {_id : user._id , email : user.email , username : user.username , role : user.role}});
   }