const OrderModel = require('../models/orderModel')
const OrderItemsModel = require('../models/orderItemModel')

// place order 
exports.placeOrder = async (req, res) => {
    let orderItemsIds = await Promise.all(req.body.orderItems.map(
        async orderItem => {
            let orderItemData = await OrderItemsModel.create({
                product: orderItem.product,
                quantity: orderItem.quantity
            })
            if (!orderItemData) {
                return res.status(400).json({ error: "something went wrong" })
            }
            return orderItemData._id
        }
    ))

    let individual_total = await Promise.all(orderItemsIds.map(async (orderItemId) => {
        let orderItemData = await OrderItemsModel.findById(orderItemId).populate('product', 'product_price')
        return orderItemData.product.product_price * orderItemData.quantity
    })
    )

    let total = individual_total.reduce((a, c) => a + c)

    let order = await OrderModel.create({
        orderItemsIds,
        total,
        user: req.body.user,
        street_address: req.body.street_address,
        city: req.body.city,
        state: req.body.state,
        postal_code: req.body.postal_code,
        phone: req.body.phone,
        country: req.body.country
    })

    if(!order){
        return res.status(400).json({error:"Failed to place order"})
    }

    res.send(order)

}


/*

orderItems: [{product: 'a', quantity:2}, {product: 'b', quantity: 4}],
user: '',
shipping_address: {....}
*/

