exports.testFunction = (request , response) => {
    response.send('good morning');
}


exports.hello = (request , response) => {
    // response.send({message : 'hello world'});
    response.json({message : 'hello word'});
}