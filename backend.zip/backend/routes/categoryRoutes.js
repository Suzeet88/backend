const express = require("express");
const {
  addcategory,
  getallcategories,
  getCategoryDetails,
  updateCategory,
  deleteCategory , 

} = require("../controllers/categoryController");
// const { validate } = require("../models/userModel");
const { validateLogin, requireAdmin } = require("../middlewares/authentication");
const { addcategoryRules , validationMethod } = require("../middlewares/categoryValidation");

const router = express.Router();

// Define the POST route for adding a category
router.post("/addcategory", requireAdmin , addcategoryRules ,validationMethod , validateLogin ,  addcategory);
router.get("/getallcategories", getallcategories);
router.get("/getCategoryDetails/:id", getCategoryDetails);
router.put("/updateCategory/:id" , requireAdmin , updateCategory)
router.delete("/deleteCategory/:id" , requireAdmin ,  deleteCategory);

module.exports = router;
