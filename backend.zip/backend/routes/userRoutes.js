const express = require('express');
const {registerUser  , verifyEmail  , getAllUsers , getUserDetails , updateUser , deleteUser, forgetPassword, resetPassword, signin} = require('../controllers/userController');
const { userRegisterRules } = require('../middlewares/categoryValidation');


const router = express.Router();


router.post('/registerUser' , userRegisterRules ,  registerUser);
router.get('/verifyEmail/:token' , verifyEmail);
router.get('/getAllUsers' , getAllUsers);
router.get('/getUserDetails/:id', getUserDetails);
router.put('/updateUser/:id', updateUser);
router.delete('/deleteUser/:id', deleteUser);
router.post('/forgotPassword' , forgetPassword);
router.post('/resetPassword/:token' , resetPassword);
router.post('/signin' , signin);
module.exports = router;
