
const express = require("express");
const {
  addProduct,
  getAllProducts,
  getProductById,
  updateProduct,
  deleteProduct,
} = require("../controllers/productController");
const upload = require("../middlewares/fileUpload");
const {
  addProductRules,
  updateProductRules,
  validationMethod,
} = require("../middlewares/productValidation");
const { requireAdmin } = require("../middlewares/authentication");

const router = express.Router();

// Define the POST route for adding a product
router.post(
  "/addproduct",
  requireAdmin,
  upload.single("product_image"),
  addProductRules, // Validation rules for adding a product
  validationMethod, // Validation method to handle errors
  addProduct
);

// Define the GET route for getting all products
router.get("/getallproducts", getAllProducts);

// Define the GET route for getting a product by ID
router.get("/getproductbyid/:id", getProductById);

// Define the PUT route for updating a product
router.put(
  "/updateproduct/:id",
  requireAdmin,
  updateProductRules, // Validation rules for updating a product
  validationMethod, // Validation method to handle errors
  updateProduct
);

// Define the DELETE route for deleting a product
router.delete("/deleteproduct/:id", requireAdmin, deleteProduct);

module.exports = router;
