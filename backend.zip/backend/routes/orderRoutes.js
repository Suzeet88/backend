const { placeOrder } = require('../controllers/orderController');

const router = require('express').Router();


router.post('/placeorder' , placeOrder);

module.exports = router;