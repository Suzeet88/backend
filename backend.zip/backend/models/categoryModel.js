const mongoose = require('mongoose');

const categorySchema = new mongoose.Schema({
     category_name:{
         type:String,
         required:true,
         trim : true
        
     }
} , {timestamps: true})


module.exports = mongoose.model('category' , categorySchema);

// id -> default , type: objectId 
// timestamps > createdAt m updatedAt